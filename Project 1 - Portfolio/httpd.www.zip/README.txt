A Pen created at CodePen.io. You can find this one at https://codepen.io/JasonStreet/pen/RjNgxB.

 A small experiment which quickly turned into something more. 