//Spark of inspiration came from this movie trailer:
// https://www.youtube.com/watch?v=qSpBnZa3Bek